import React, { useState, useEffect } from 'react';
import { Send, Loader2, MessageSquare, Sparkles, BookMarked, AlertCircle } from 'lucide-react';
import { generateAIResponse } from '../lib/googleAI';
import { useTheme } from '../context/ThemeContext';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  promptTemplateId?: string; // Optional ID of the template used
}

interface ChatSession {
  id: string;
  messages: Message[]; // Array of messages within this session
}

function Chat() {
  const { isDarkTheme } = useTheme();
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState<Message[]>(() => { // Lazy initialization
    try {
      const storedMessages = localStorage.getItem('chatHistory');
      return storedMessages ? JSON.parse(storedMessages) : [];
    } catch (error) {
      console.error("Error loading chat history from localStorage:", error);
      return []; // Return an empty array in case of an error.
    }
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [templateVariables, setTemplateVariables] = useState<{ [key: string]: string }>({}); // Track template variable values.
  const [chatSummary, setChatSummary] = useState<{ [date: string]: { id: string, content: string, time: string }[] }>({});

  const promptTemplates = [
    // 1. Content Generation/Writing
    {
      id: '1',
      name: 'Content Generation',
      template:
        'Write a {{content_type}} about {{topic}} for {{target_audience}}. The tone should be {{tone}} and the length should be approximately {{length}} words. Include the following keywords: {{keywords}}.',
      variables: [
        { name: 'content_type', type: 'select', label: 'Content Type', options: ['Blog Post', 'Email', 'Social Media Post', 'Article', 'Story'] },
        { name: 'topic', type: 'text', label: 'Topic' },
        { name: 'target_audience', type: 'text', label: 'Target Audience' },
        { name: 'tone', type: 'select', label: 'Tone', options: ['Formal', 'Informal', 'Humorous', 'Professional'] },
        { name: 'length', type: 'number', label: 'Approximate Word Count' },
        { name: 'keywords', type: 'text', label: 'Keywords (comma-separated)' },
      ],
    },

    // 2. Summarization
    {
      id: '2',
      name: 'Summarization',
      template: 'Summarize the following text in {{length}} sentences or less: {{text}}. Focus on the key points related to {{focus_area}}.',
      variables: [
        { name: 'length', type: 'number', label: 'Maximum Number of Sentences' },
        { name: 'text', type: 'textarea', label: 'The Text to Summarize' },
        { name: 'focus_area', type: 'text', label: 'Specific Aspect to Focus On (Optional)' },
      ],
    },

    // 3a. Code Generation
    {
      id: '3a',
      name: 'Code Generation',
      template: 'Generate {{language}} code to {{functionality}}. Consider these constraints: {{constraints}}. The code should be {{style}}.',
      variables: [
        { name: 'language', type: 'select', label: 'Language', options: ['JavaScript', 'Python', 'Java', 'C++', 'Go'] },
        { name: 'functionality', type: 'text', label: 'What should the code do?' },
        { name: 'constraints', type: 'text', label: 'Any Limitations or Requirements?' },
        { name: 'style', type: 'select', label: 'Code Style', options: ['Clean', 'Efficient', 'Readable'] },
      ],
    },

    // 3b. Code Explanation
    {
      id: '3b',
      name: 'Code Explanation',
      template: 'Explain the following code snippet:\n{{code}}. Focus on {{aspects}}. Provide examples of how to use it.',
      variables: [
        { name: 'code', type: 'textarea', label: 'The Code to Explain' },
        { name: 'aspects', type: 'text', label: 'Specific Aspects to Explain (Optional)' },
      ],
    },

    // 4. Translation
    {
      id: '4',
      name: 'Translation',
      template: 'Translate the following text from {{source_language}} to {{target_language}}:\n{{text}}',
      variables: [
        { name: 'source_language', type: 'select', label: 'Source Language', options: ['English', 'Spanish', 'French', 'German', 'Chinese', 'Japanese'] }, // Add more languages
        { name: 'target_language', type: 'select', label: 'Target Language', options: ['English', 'Spanish', 'French', 'German', 'Chinese', 'Japanese'] }, // Add more languages
        { name: 'text', type: 'textarea', label: 'The Text to Translate' },
      ],
    },

    // 5. Question Answering
    {
      id: '5',
      name: 'Question Answering',
      template: 'Answer the following question, using the context provided:\nQuestion: {{question}}\nContext: {{context}}',
      variables: [
        { name: 'question', type: 'text', label: 'The Question to Answer' },
        { name: 'context', type: 'textarea', label: 'Relevant Information (Optional)' },
      ],
    },

    // 6. Creative Writing / Storytelling
    {
      id: '6',
      name: 'Storytelling',
      template: 'Continue the following story:\n{{story_so_far}}\nThe next section should include: {{plot_points}} and have a {{mood}} mood.',
      variables: [
        { name: 'story_so_far', type: 'textarea', label: 'The Existing Story Text' },
        { name: 'plot_points', type: 'text', label: 'Keywords for Next Part (comma-separated)' },
        { name: 'mood', type: 'select', label: 'Mood', options: ['Exciting', 'Suspenseful', 'Sad', 'Humorous'] },
      ],
    },

    // 7. Idea Generation / Brainstorming
    {
      id: '7',
      name: 'Brainstorming',
      template: 'Brainstorm {{number_of_ideas}} ideas for {{topic}}. These ideas should be related to {{keywords}}.',
      variables: [
        { name: 'number_of_ideas', type: 'number', label: 'How Many Ideas?' },
        { name: 'topic', type: 'text', label: 'The Topic to Brainstorm About' },
        { name: 'keywords', type: 'text', label: 'Keywords to Guide Ideas (Optional)' },
      ],
    },

    // 8. Explain Concept
    {
      id: '8',
      name: 'Explain Concept',
      template: 'Explain {{concept}} in simple terms',
      variables: [{ name: 'concept', type: 'text', label: 'Concept' }],
    },

    // 9. Code Review
    {
      id: '9',
      name: 'Code Review',
      template: 'Review this code and suggest improvements:\n{{code}}',
      variables: [{ name: 'code', type: 'textarea', label: 'Code' }],
    },

    // 10. Summarize Text (original)
    {
      id: '10',
      name: 'Summarize Text',
      template: 'Summarize the following text:\n{{text}}',
      variables: [{ name: 'text', type: 'textarea', label: 'Text' }],
    },
  ];

  const promptCategories = [
    'concept',
    'code',
    'text',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

      const newSessionId = Date.now().toString(); // Unique session ID
      const newUserMessage: Message = {
          id: newSessionId + '-user',
          content: prompt,
          role: 'user',
          timestamp: new Date(),
          promptTemplateId: selectedTemplate || undefined,
      };

      setIsLoading(true);
      setError(null);

      try {
          const aiResponse = await generateAIResponse(prompt);
          const newAssistantMessage: Message = {
              id: newSessionId + '-ai',
              content: aiResponse,
              role: 'assistant',
              timestamp: new Date(),
              promptTemplateId: selectedTemplate || undefined,
          };

          //Create the CHAT SESSION: this is critical
          const newSession: ChatSession = {
              id: newSessionId,
              messages: [newUserMessage, newAssistantMessage],
          };

          //Update the chatSessions state
          setMessages(prev => [newSession, ...prev]); // Add to the beginning of array

      } catch (err: any) {
          setError('Failed to generate response. Please try again.');
      } finally {
          setIsLoading(false);
          setPrompt('');
          setTemplateVariables({}); // Clear variables after submission
      }
  };

  const applyTemplate = (templateObj: { id: string; name: string; template: string; variables?: any[] }) => {
    // Update type of variables
    const { template, variables } = templateObj;

    if (variables && variables.length > 0) {
      // Initialize template variables in state
      const initialVariables: { [key: string]: string } = {};
      variables.forEach(variable => {
        initialVariables[variable.name] = ''; // Use variable.name
      });
      setTemplateVariables(initialVariables);
      setPrompt(template); // Set the template in the prompt for editing.
    } else {
      setPrompt(template);
      setTemplateVariables({});
    }
    setSelectedTemplate(templateObj.id);
  };

  const handleVariableChange = (variableName: string, value: string) => {
    setTemplateVariables(prev => ({ ...prev, [variableName]: value }));
    // Update prompt dynamically.
    setPrompt(prevPrompt => {
      const template = promptTemplates.find(t => t.id === selectedTemplate)?.template || '';
      let newPrompt = template;
      const allVariables = promptTemplates.find(t => t.id === selectedTemplate)?.variables;

      if (allVariables) {
        allVariables.forEach(variable => {
          const varName = variable.name;
          const varValue = templateVariables[varName] || (variableName === varName ? value : ''); // Ensure current variable is updated
          newPrompt = newPrompt.replace(`{{${varName}}}`, varValue);
        });
      }

      return newPrompt;
    });
  };

  useEffect(() => {
    try {
      localStorage.setItem('chatHistory', JSON.stringify(messages));
    } catch (error) {
      console.error("Error saving chat history to localStorage:", error);
    }
  }, [messages]); // Save when messages change

  useEffect(() => {
    const calculateChatSummary = () => {
      const summary: { [date: string]: { id: string, content: string, time: string }[] } = {};

      messages.forEach(message => {
          // Only show user prompts
          if (message.role === 'assistant') return;

          const date = new Date(message.timestamp).toLocaleDateString(); // Format the date
          const time = new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); // Format the time

          if (!summary[date]) {
              summary[date] = [];
          }
          summary[date].push({ id: message.id, content: message.content, time: time });
      });

      setChatSummary(summary);
    };

    calculateChatSummary();
}, [messages]);

  return (
    <div className={`min-h-screen pt-16 ${isDarkTheme ? 'bg-black text-white' : 'bg-gray-50 text-gray-900'}`}>
      <div className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Templates Section */}
            <div
              className={`rounded-lg p-4 shadow-lg border ${isDarkTheme ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-200'}`}
            >
              <div className="flex items-center gap-2 mb-4">
                <BookMarked className={`w-5 h-5 ${isDarkTheme ? 'text-gray-400' : 'text-gray-600'}`} />
                <h2 className="font-semibold">Templates</h2>
              </div>
              <div className="space-y-2">
                {promptTemplates.map(template => (
                  <button
                    key={template.id}
                    onClick={() => applyTemplate(template)}
                    className={`w-full text-left text-sm p-2 rounded transition-colors ${
                      isDarkTheme ? 'text-gray-400 hover:bg-zinc-800' : 'text-gray-600 hover:bg-gray-100'
                    } ${selectedTemplate === template.id ? 'font-bold' : ''}`} // Highlight selected template
                  >
                    {template.name}
                  </button>
                ))}
              </div>
            </div>

            {/* AI History */}
            <div className={`rounded-lg p-4 shadow-lg border ${isDarkTheme ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-200'}`}>
                <h2 className="font-semibold mb-2">AI History</h2>
                <div className="space-y-2">
                    {Object.entries(chatSummary)
                        .sort((a, b) => new Date(b[0]).getTime() - new Date(a[0]).getTime()) // Sort dates in descending order
                        .map(([date, prompts]) => (
                            <div key={date}>
                                <h3 className="text-sm font-medium">{date}</h3>
                                <ul className="list-disc list-inside">
                                    {prompts.map(message => (
                                        <li key={message.id} className="text-xs">
                                            {message.time} - {message.content.substring(0, 50)}...
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div
              className={`rounded-lg shadow-lg min-h-[600px] flex flex-col border ${
                isDarkTheme ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-gray-200'
              }`}
            >
              {/* Messages */}
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {error && (
                  <div className="flex items-center gap-2 p-4 bg-red-900/20 text-red-400 rounded-lg border border-red-900/50">
                    <AlertCircle className="w-5 h-5" />
                    <p>{error}</p>
                  </div>
                )}
                {messages.map(message => (
                  <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div
                      className={`max-w-[80%] rounded-lg p-4 ${
                        message.role === 'user'
                          ? isDarkTheme
                            ? 'bg-white text-black'
                            : 'bg-gray-900 text-white'
                          : isDarkTheme
                            ? 'bg-zinc-800 text-white border border-zinc-700'
                            : 'bg-gray-100 text-gray-900 border border-gray-200'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        {message.role === 'user' ? (
                          <MessageSquare className="w-4 h-4" />
                        ) : (
                          <Sparkles className="w-4 h-4" />
                        )}
                        <span className="text-sm font-medium">{message.role === 'user' ? 'You' : 'AI Assistant'}</span>
                      </div>
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div
                      className={`rounded-lg p-4 border ${isDarkTheme ? 'bg-zinc-800 border-zinc-700' : 'bg-gray-100 border-gray-200'}`}
                    >
                      <Loader2
                        className={`w-5 h-5 animate-spin ${isDarkTheme ? 'text-gray-400' : 'text-gray-600'}`}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Input Form */}
              <form onSubmit={handleSubmit} className={`border-t p-4 ${isDarkTheme ? 'border-zinc-800' : 'border-gray-200'}`}>
                {/* Template Variable Inputs */}
                {selectedTemplate &&
                  promptTemplates
                    .find(t => t.id === selectedTemplate)
                    ?.variables?.map(variable => (
                      <div key={variable.name} className="mb-2">
                        <label
                          htmlFor={variable.name}
                          className={`block text-sm font-medium ${isDarkTheme ? 'text-gray-300' : 'text-gray-700'}`}
                        >
                          {variable.label}:
                        </label>
                        {variable.type === 'text' && (
                          <input
                            type="text"
                            id={variable.name}
                            value={templateVariables[variable.name] || ''}
                            onChange={e => handleVariableChange(variable.name, e.target.value)}
                            className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm ${
                              isDarkTheme ? 'bg-zinc-800 text-white border-zinc-700' : 'bg-white text-gray-900'
                            }`}
                          />
                        )}
                        {variable.type === 'number' && (
                          <input
                            type="number"
                            id={variable.name}
                            value={templateVariables[variable.name] || ''}
                            onChange={e => handleVariableChange(variable.name, e.target.value)}
                            className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm ${
                              isDarkTheme ? 'bg-zinc-800 text-white border-zinc-700' : 'bg-white text-gray-900'
                            }`}
                          />
                        )}
                        {variable.type === 'select' && (
                          <select
                            id={variable.name}
                            value={templateVariables[variable.name] || ''}
                            onChange={e => handleVariableChange(variable.name, e.target.value)}
                            className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm ${
                              isDarkTheme ? 'bg-zinc-800 text-white border-zinc-700' : 'bg-white text-gray-900'
                            }`}
                          >
                            <option value="">Select an option</option>
                            {variable.options?.map(option => (
                              <option key={option} value={option}>
                                {option}
                              </option> // Use optional chaining
                            ))}
                          </select>
                        )}
                        {variable.type === 'textarea' && (
                          <textarea
                            id={variable.name}
                            value={templateVariables[variable.name] || ''}
                            onChange={e => handleVariableChange(variable.name, e.target.value)}
                            className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm ${
                              isDarkTheme ? 'bg-zinc-800 text-white border-zinc-700' : 'bg-white text-gray-900'
                            }`}
                            rows={4} // Adjust the number of rows as needed
                          />
                        )}
                      </div>
                    ))}

                <div className="flex gap-4">
                  <textarea
                    value={prompt}
                    onChange={e => setPrompt(e.target.value)}
                    placeholder="Type your message here..."
                    className={`flex-1 resize-none rounded-lg p-3 border focus:outline-none focus:ring-2 focus:border-transparent ${
                      isDarkTheme
                        ? 'bg-zinc-800 border-zinc-700 text-white placeholder-gray-500 focus:ring-white'
                        : 'bg-gray-100 border-gray-200 text-gray-900 placeholder-gray-500 focus:ring-gray-900'
                    }`}
                    rows={3}
                  />
                  <button
                    type="submit"
                    disabled={isLoading || !prompt.trim()}
                    className={`self-end rounded-lg px-4 py-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition-colors ${
                      isDarkTheme ? 'bg-white text-black hover:bg-gray-200' : 'bg-gray-900 text-white hover:bg-gray-800'
                    }`}
                  >
                    <Send className="w-4 h-4" />
                    <span>Send</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Chat;